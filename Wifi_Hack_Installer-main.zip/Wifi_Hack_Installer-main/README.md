# THBD
### Wifi_Hack_Installer
### Note:Your Device Must Be Rooted.
  
   🤟 Installation:

```
$ pkg update && pkg upgrade

$ pkg install git python

$ git clone https://github.com/Mahfuz-THBD/Wifi_Hack_Installer

$ cd Wifi_Hack_Installer

$ python Installer.py
```
# Wifi_Hack Repo

https://github.com/Mahfuz-THBD/Wifi_Hack
